# CacaoTrace — projet Flutter Android

Application de traçabilité cacao conçue pour le terrain au Cameroun, avec priorité au mode hors connexion.

## Ce qui est inclus dans cette V1
- Producteurs : identité, téléphone, CNI, région, département, commune, village, coopérative.
- Parcelles : GPS, mesure par marche, points successifs, polygone, superficie en hectares, photo, année de plantation, variété, droit foncier, agroforesterie, certification.
- Base SQLite locale.
- File d'attente de synchronisation (`sync_queue`) pour préparer la synchronisation serveur.
- Tableau de bord.
- Navigation de la chaîne producteur → parcelle → récolte → lot → acheteur → EUDR.
- Structure de base pour les données administratives camerounaises.

## Important sur les cartes hors connexion
Le GPS fonctionne sans internet si la localisation du téléphone est activée. La couche de fond OpenStreetMap affichée par cette V1 nécessite une connexion. La V2 peut intégrer des tuiles/MBTiles hors connexion pour la carte complète.

## Compiler avec Android Studio
1. Installer Flutter et le SDK Android.
2. Dans Android Studio, installer le plugin Flutter et Dart.
3. Décompresser ce dossier.
4. Android Studio → **Open** → sélectionner le dossier `CacaoTrace`.
5. Dans le terminal du projet :
   `flutter pub get`
6. Vérifier :
   `flutter doctor`
7. Brancher un téléphone Android avec le mode développeur + débogage USB, ou créer un émulateur.
8. Lancer :
   `flutter run`
9. Pour générer l'APK :
   `flutter build apk --release`
10. APK : `build/app/outputs/flutter-apk/app-release.apk`

## Première installation sur téléphone
À la première utilisation, Android demandera l'autorisation de localisation et de caméra. Autoriser la localisation précise pour une mesure de parcelle fiable.

## Signature Play Store
Pour publier sur Google Play, créer ensuite une clé de signature et utiliser `flutter build appbundle --release`.

## Créateur intégré
Nguimkeng Chouna Ivaness — Ingénieur agronome — ivanessnguimkeng1@gmail.com
